//go:build tools

package main

import (
	_ "gioui.org/cmd/gogio"
)
