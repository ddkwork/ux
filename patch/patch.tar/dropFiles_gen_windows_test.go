package app

import (
	"io/fs"
	"path/filepath"
	"strings"
	"testing"

	"github.com/ddkwork/golibrary/stream"
)

//SetTitleBarIsDark
//genDropFilesEventArg

func TestGenDropFiles(t *testing.T) {
	stream.CopyFile("fix/os_windows.go", "../vendor/gioui.org/app/os_windows.go")
	stream.CopyFile("fix/dropFiles_gen_windows.go", "../vendor/gioui.org/app/dropFiles_gen_windows.go")
	for _, s := range getOsFiles() {
		if filepath.Base(s) == "os_windows.go" {
			continue
		}
		println(s)
		b := stream.NewBuffer(s)
		if b.Contains(callbackDefault) {
			continue
		}
		stream.WriteAppend(s, callbackDefault)
	}
}

var callbackDefault = `
var dragHandler = func(files []string) {}

func FileDropCallback(fn func(files []string)) {
	dragHandler = fn
}
`

func getOsFiles() []string {
	var paths []string
	filepath.Walk("../vendor/gioui.org/app", func(path string, info fs.FileInfo, err error) error {
		if strings.HasPrefix(filepath.Base(path), "os_") {
			if filepath.Ext(path) == ".go" {
				paths = append(paths, path)
			}
		}
		return err
	})
	return paths
}
